---
id: versions
title: Versions
---

Now that you understand what makes Eightshift tick, here is a quick reminder about what library versions this documentation refers to.

[![docs-source](https://img.shields.io/badge/version--4.0.0-eigthshift--boilerplate-red?style=for-the-badge&logo=)](https://github.com/infinum/eightshift-boilerplate)

[![docs-source](https://img.shields.io/badge/version--1.0.0-eigthshift--boilerplate--plugin-important?style=for-the-badge&logo=)](https://github.com/infinum/eightshift-boilerplate)

[![docs-source](https://img.shields.io/badge/version--2.0.0-eigthshift--libs-blue?style=for-the-badge&logo=)](https://github.com/infinum/eightshift-libs)

[![docs-source](https://img.shields.io/badge/version--2.0.0-eigthshift--frontend--libs-yellow?style=for-the-badge&logo=)](https://github.com/infinum/eightshift-frontend-libs)

<div class="legacy-badge legacy-badge--v4"></div>
