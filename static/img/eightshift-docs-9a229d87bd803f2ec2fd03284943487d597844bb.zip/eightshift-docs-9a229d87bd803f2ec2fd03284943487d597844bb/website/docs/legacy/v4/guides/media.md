---
id: media
title: Media
---

[![docs-source](https://img.shields.io/badge/source-eigthshift--boilerplate-red?style=for-the-badge&logo=wordpress&labelColor=2a2a2a)](https://github.com/infinum/eightshift-boilerplate/blob/develop/src/media/class-media.php)

Media class is located in `project`. It extends `Eightshift_Libs\Media\Media` class.

This class is used to add all custom project implementation for media like adding custom image size, enabling SVG image, etc.

<div class="legacy-badge legacy-badge--v4"></div>
